<?php
use MediaWiki\Auth\AuthManager;
use MediaWiki\Auth\AuthenticationResponse;

class Fail2LogClass {

public static function onAuthManagerLoginAuthenticateAudit ( AuthenticationResponse $response, $user, $username ) { 
	global $wgFail2LogFile;

#	if (!file_exists ($wgFail2LogFile)) {
#		touch ($wgFail2LogFile);
#		chmod ($wgFail2LogFile, 0755);
#		chown ($wgFail2LogFile, www-data );
#	}
	

	$time = date("Y-m-d H:i:s T");                                                                                                                                                   
	$ip = $_SERVER['REMOTE_ADDR'];

	if ( $response->status === AuthenticationResponse::FAIL ) {
		error_log ( "Failed:$ip $time $username\n", 3, $wgFail2LogFile );
	}
    }
}
